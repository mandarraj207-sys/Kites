.text
main:
    ld   x5, 0(x10)
    add  x6, x5, x1
    ld   x7, 8(x10)
    add  x8, x7, x2
    sub  x9, x3, x4
    xor  x11, x12, x13
    add  x14, x6, x8