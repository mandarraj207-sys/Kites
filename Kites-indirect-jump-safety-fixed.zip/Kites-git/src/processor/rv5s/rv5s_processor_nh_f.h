/**
 * @file rv5s_processor_nh_f.h
 * @brief Header for the 5-stage pipelined VM (RV5S) in Mode 2: No Hazard Detection, With
 * Forwarding.
 * @author Atharva and Harshit
 */
#pragma once

#include "processor/pipeline_registers.h"
#include "processor/rv5s/rv5s_control_unit.h"
#include "processor/rv5s/rv5s_processor_base.h"
#include <iostream>
#include <stack>
#include <vector>

namespace Kites
{
// --- Programmer NOP Requirements for Mode 2 ---
// * Data Hazards (ALU-ALU): 0 NOPs (Handled by Forwarding)
// * Load-Use Hazards: 1 NOP (Hardware cannot forward in time)
// * Conditional Branch Hazards: 3 NOPs (Same as Mode 1, no prediction/detection)
// * Unconditional Jumps (JAL/JALR): 1 NOP (Same as Mode 1)

class RV5StageProcessorNHF : public RV5StageVM_Base
{
  public:
    // Constructor and Destructor
    RV5StageProcessorNHF();
    ~RV5StageProcessorNHF() = default;

    // Overridden virtual functions from ProcessorBase
    // void Run() override;
    // void DebugRun() override;
    void Step() override;
    void Reset() override;

    void PrintType()
    {
        std::cout << "RV5StageProcessorNHF" << std::endl;
    }
    void SetActiveWireNames() override;

  private:
    // --- Private methods for each pipeline stage ---
    void pipeline_fetch() override;
    // void pipeline_decode() override;
    void pipeline_execute() override;
    uint64_t pipeline_execute_float() override;
    uint64_t pipeline_execute_double() override;
    // void pipeline_memory() override;
    //  void pipeline_writeback() override;

    // void print_pipeline_registers_debug();
    void handle_syscall() override;
};
}//namespace Kites