#include "compilertab.h"
#include "config/app_settings.h"
#include "ui_compilertab.h"
#include <QClipboard>
#include <QDir>
#include <QFile>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QProcess>
#include <QStyle>
#include <QTemporaryFile>
#include <QTextStream>

namespace Kites
{

CompilerTab::CompilerTab(QWidget *parent) : KitesTab(parent), ui(new Ui::CompilerTab)
{
    ui->setupUi(this);
    connect(ui->convertToAssemblyButton, &QPushButton::clicked, this,
            &CompilerTab::onConvertToAssemblyClicked);
    connect(ui->copyToMainEditorButton, &QPushButton::clicked, this,
            &CompilerTab::onCopyToMainEditorClicked);
    connect(&AppSettings::getInstance(), &AppSettings::compilerOutputBorderStyleChangedSignal, this,
            &CompilerTab::applyOutputBorderStyle);
    ui->splitter_2->setStretchFactor(0, 3);
    ui->splitter_2->setStretchFactor(1, 1);
    ui->outputTextEdit->setReadOnly(true);
    applyOutputBorderStyle();
}

void CompilerTab::applyOutputBorderStyle()
{
    QString styleName;
    switch (AppSettings::getInstance().compilerOutputBorderStyle())
    {
        case BorderStyle::None:   styleName = "none";   break;
        case BorderStyle::Subtle: styleName = "subtle"; break;
        case BorderStyle::Full:   styleName = "full";   break;
    }
    ui->outputTextEdit->setProperty("borderStyle", styleName);
    ui->outputTextEdit->style()->unpolish(ui->outputTextEdit);
    ui->outputTextEdit->style()->polish(ui->outputTextEdit);
}

QString CompilerTab::getUsersCompilerOptions()
{
    // we can further check if the options are valid or not before returning
    // for for now just returning the raw string
    return ui->compilerOptionslineEdit->text().trimmed();
}

void CompilerTab::onCopyToMainEditorClicked()
{
    QString assemblyCode = ui->outputTextEdit->toPlainText().trimmed();
    if (assemblyCode.isEmpty())
    {
        // No assembly to copy
        return;
    }

    // Emit a signal or directly call a method to send this assembly code to the main editor
    // For example, if you have a signal:
    // emit assemblyReadyForMainEditor(assemblyCode);
    // Or if you have direct access to the main editor instance:
    // mainEditor->setPlainText(assemblyCode);

    // For demonstration, let's just copy it to the clipboard
    QClipboard *clipboard = QGuiApplication::clipboard();
    clipboard->setText(assemblyCode);
}

void CompilerTab::onConvertToAssemblyClicked()
{
    // 1. Read C++ from input text edit
    QString cppSource = ui->inputTextEdit->toPlainText();

    if (cppSource.trimmed().isEmpty())
    {
        ui->outputTextEdit->setPlainText("Error: Input is empty.");
        return;
    }

    QString escaped = cppSource;
    escaped.replace("\\", "\\\\");
    escaped.replace("\"", "\\\"");
    escaped.replace("\n", "\\n");
    escaped.replace("\r", "\\r");
    escaped.replace("\t", "\\t");

    // QString jsonBody = QString(R"({
    //     "source": "%1",
    //     "options": {
    //         "userArguments": "-O1 -march=rv64gc -mabi=lp64d -fno-exceptions",
    //         "filters": {
    //             "binary":      false,
    //             "directives":  true,
    //             "commentOnly": true,
    //             "trim":        true,
    //             "labels":      false,
    //             "intel":       false
    //         },
    //         "compilerOptions": {}
    //     }
    // })").arg(escaped);

    QJsonObject filters;
    filters["binary"] = false;
    filters["directives"] = true;
    filters["commentOnly"] = true;
    filters["trim"] = true;
    filters["labels"] = true;

    QJsonObject options;
    options["userArguments"] = "-march=rv64gc -mabi=lp64d "
                               "-fno-exceptions "
                               "-fno-asynchronous-unwind-tables "
                               "-fno-unwind-tables "
                               "-fno-ident " +
                               getUsersCompilerOptions();
    options["filters"] = filters;

    QJsonObject payload;
    payload["source"] = cppSource;
    payload["options"] = options;

    QByteArray jsonBody = QJsonDocument(payload).toJson(QJsonDocument::Compact);

    QUrl url("https://godbolt.org/api/compiler/rv64-gcc1520/compile");
    QNetworkRequest request(url);
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");
    request.setRawHeader("Accept", "application/json");

    ui->outputTextEdit->setPlainText("Compiling via Godbolt API...");
    ui->convertToAssemblyButton->setEnabled(false); // prevent double-clicks
    // 2. Write to temp file

    // 5. Send POST request
    QNetworkAccessManager *manager = new QNetworkAccessManager(this);
    QNetworkReply *reply = manager->post(request, jsonBody);

    connect(
        reply, &QNetworkReply::finished, this,
        [this, reply, manager]()
        {
            // Re-enable button
            ui->convertToAssemblyButton->setEnabled(true);

            // Check for network-level errors (no internet, timeout, etc.)
            if (reply->error() != QNetworkReply::NoError)
            {
                ui->outputTextEdit->setPlainText("Network error: " + reply->errorString() +
                                                 "\n\nMake sure you have an internet connection.");
                reply->deleteLater();
                manager->deleteLater();
                return;
            }

            // 7. Parse JSON response
            QByteArray responseData = reply->readAll();
            QJsonDocument doc = QJsonDocument::fromJson(responseData);

            if (doc.isNull() || !doc.isObject())
            {
                ui->outputTextEdit->setPlainText("Error: Invalid response from Godbolt API.");
                reply->deleteLater();
                manager->deleteLater();
                return;
            }

            QJsonObject root = doc.object();

            // 8. Check compiler exit code
            int exitCode = root["code"].toInt(-1);

            // 9. Collect stderr (compiler warnings/errors)
            QString stderrOutput;
            QJsonArray stderrLines = root["stderr"].toArray();
            for (const QJsonValue &line : stderrLines)
                stderrOutput += line.toObject()["text"].toString() + "\n";

            // If compilation failed, show errors
            if (exitCode != 0)
            {
                ui->outputTextEdit->setPlainText("Compilation failed (exit code " +
                                                 QString::number(exitCode) + "):\n\n" +
                                                 stderrOutput);
                reply->deleteLater();
                manager->deleteLater();
                return;
            }

            // 10. Extract assembly lines from "asm" array
            QString asmOutput;
            QJsonArray asmLines = root["asm"].toArray();

            if (asmLines.isEmpty())
            {
                ui->outputTextEdit->setPlainText("Error: No assembly output returned.");
                reply->deleteLater();
                manager->deleteLater();
                return;
            }

            for (const QJsonValue &line : asmLines)
            {
                QString text = line.toObject()["text"].toString();
                asmOutput += text + "\n";
            }

            // 11. Show warnings (if any) above the assembly
            QString finalOutput;
            if (!stderrOutput.trimmed().isEmpty())
                finalOutput +=
                    "// Warnings:\n// " + stderrOutput.trimmed().replace("\n", "\n// ") + "\n\n";
            finalOutput += asmOutput;

            ui->outputTextEdit->setPlainText(cleanAssembly(finalOutput));

            reply->deleteLater();
            manager->deleteLater();
        });
}

QString CompilerTab::cleanAssembly(const QString &rawAssembly)
{
    QStringList result;
    QStringList lines = rawAssembly.split('\n');

    // Track if we're inside a real code section
    bool inTextSection = false;

    for (QString line : lines)
    {
        QString trimmed = line.trimmed();

        // Skip completely empty lines (keep single blank lines for spacing)
        if (trimmed.isEmpty())
        {
            if (!result.isEmpty() && !result.last().isEmpty())
                result << "";
            continue;
        }

        // Detect section changes
        if (trimmed.startsWith(".section"))
        {
            inTextSection = trimmed.contains(".text");
            continue;
        }
        if (trimmed == ".text")
        {
            inTextSection = true;
            continue;
        }

        // Skip all debug sections entirely
        if (trimmed.startsWith(".debug_") || trimmed.startsWith(".Ldebug") ||
            trimmed.startsWith(".Ltext") || trimmed.startsWith(".Letext") ||
            trimmed.startsWith(".LFB") || trimmed.startsWith(".LFE") || trimmed.startsWith(".LVL"))
            continue;

        // Skip debug/meta directives
        if (trimmed.startsWith(".file") || trimmed.startsWith(".loc ") ||
            trimmed.startsWith(".cfi_") || trimmed.startsWith(".option") ||
            trimmed.startsWith(".attribute") || trimmed.startsWith(".ident") ||
            trimmed.startsWith(".size") || trimmed.startsWith(".uleb128") ||
            trimmed.startsWith(".sleb128") || trimmed.startsWith(".4byte") ||
            trimmed.startsWith(".2byte") || trimmed.startsWith(".byte") ||
            trimmed.startsWith(".8byte") || trimmed.startsWith(".string") ||
            trimmed.startsWith(".LASF") || trimmed.startsWith(".note"))
            continue;

        // Keep .globl, .type, .align — they're useful context
        // Keep function labels (e.g. "main:")
        // Keep actual instructions (indented lines)

        result << line;
    }

    // Remove trailing blank lines
    while (!result.isEmpty() && result.last().trimmed().isEmpty())
        result.removeLast();

    return result.join('\n');
}

CompilerTab::~CompilerTab()
{
    delete ui;
}
} // namespace Kites
