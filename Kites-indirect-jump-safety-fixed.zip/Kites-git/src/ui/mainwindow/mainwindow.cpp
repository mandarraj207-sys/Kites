#include <array>
#include <cstdint>
#include "mainwindow.h"
#include "assembler/assembler.h"
#include "common/assembled_program.h"
#include "common/globals.h"
#include "custom_pseudo_manager/custom_pseudo_manager.h"
#include "processor/processor_manager.h"
#include "ui/cache_tab/cachetab.h"
#include "ui/compiler_tab/compilertab.h"
#include "ui/dialogs/processor_dialog.h"
#include "ui/dialogs/settings_dialog.h"
#include "ui/editor_tab/editortab.h"
#include "ui/memory_tab/memorytab.h"
#include "ui/processor_tab/processortab.h"
#include "ui/profiler_tab/profilertab.h"
#include "ui/optimizer_tab/optimizertab.h"
#include "ui/theme/icon_manager.h"
#include "ui_mainwindow.h"
#include "utils/utils.h"
#include <QActionGroup>
#include <QFileDialog>
#include <QHBoxLayout>
#include <QLabel>
#include <QSpinBox>
#include <QWidgetAction>
#include <QSplitter>
#include <QMessageBox>
#include <QDebug>
#include <QPushButton>

namespace Kites
{
MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent)
// ui(new Ui::MainWindow)
{
    // ui->setuoUi(this);
    setWindowTitle("Kites RISC-V Simulator");
    setWindowIcon(QIcon(":/icons/kite.png"));
    ThemeManager::getInstance(); // applies the persisted (or default) theme before any UI is built
    setupVmStateDirectory();

    // well run the vm in a separate thread to keep the ui responsive
    // do not touch these 4 line unless you really know what you are doing
    m_processorManager = new ProcessorManager();
    m_processorThread = new QThread(this);
    m_processorManager->moveToThread(m_processorThread);
    m_processorThread->start();


    m_registerContainer = new RegisterContainer(this, m_processorManager->getRegisterFile());
    QWidget *central = new QWidget(this);
    QHBoxLayout *mainLayout = new QHBoxLayout(central);
    QSplitter *splitter = new QSplitter(Qt::Horizontal, this);

    m_stackedTabs = new QStackedWidget(this);
    m_sidebar = new QListWidget(this);
    setUpStatusBar();
    setUpSidebar();
    setUpToolBar();
    setUpMenubar();
    setUpTabs();

    // m_registerContainer = new RegisterContainer(this);
    mainLayout->setSpacing(0);
    mainLayout->setContentsMargins(0, 0, 0, 0);
    splitter->addWidget(m_stackedTabs);
    splitter->addWidget(m_registerContainer);
    splitter->widget(1)->setMaximumWidth(350);

    // outer splitter makes the sidebar width user-adjustable (Zed-style)
    QSplitter *outerSplitter = new QSplitter(Qt::Horizontal, this);
    outerSplitter->addWidget(m_sidebar);
    outerSplitter->addWidget(splitter);
    outerSplitter->setCollapsible(1, false);
    outerSplitter->setStretchFactor(0, 0);
    outerSplitter->setStretchFactor(1, 1);
    outerSplitter->setSizes({m_sidebar->sizeHintForColumn(0) + 24, 1000});

    mainLayout->addWidget(outerSplitter);

    setCentralWidget(central);
    resize(1200, 800);
    connect(this, &MainWindow::runProcessorSignal, m_processorManager, &ProcessorManager::runSlot);
    // well temporarily disable the toolbar buttons when vm is running
    connect(m_processorManager, &ProcessorManager::runFinishedSignal, this, &MainWindow::runFinishedSlot);
    connect(m_processorManager, &ProcessorManager::runErrorSignal, this,
            [this](const QString &errorMessage, int sourceLine)
            {
                // first we enable the toolbar buttons

                if (m_benchmarkStage != BenchmarkStage::Idle) {
                    m_benchmarkStage = BenchmarkStage::Idle;
                    m_benchmarkOriginalProgram.reset();
                    m_benchmarkOptimizedProgram.reset();
                }

                runFinishedSlot();
                auto editorTab = dynamic_cast<EditorTab *>(m_tabs[TabIndex::EditorTabIndex]);
                if (editorTab)
                {
                    editorTab->showRuntimeError(sourceLine, errorMessage);
                }
                QMessageBox::critical(this, "Runtime Error", errorMessage);
            });

    //TODO : instead of using lambda just connect the signal to the functions directly
    connect(m_processorManager, &ProcessorManager::updateDisassemblySignal, this,
            [this](const QString &disassemblyText)
            {
                auto editorTab = dynamic_cast<EditorTab *>(m_tabs[TabIndex::EditorTabIndex]);
                if (editorTab)
                {
                    editorTab->updateDisassemblyView(disassemblyText.toStdString());
                }
            });
    connect(m_processorManager, &ProcessorManager::updateEditorHighlightSignal, this,
            [this](const std::vector<std::pair<int,std::string>> &editorLines,
            const std::vector<std::pair<int,std::string>> &disassemblyLines)
            {
                auto editorTab = dynamic_cast<EditorTab *>(m_tabs[TabIndex::EditorTabIndex]);
                if (editorTab)
                {
                    editorTab->highlightLines(editorLines, disassemblyLines);
                }
            });
    connect(&ThemeManager::getInstance(), &ThemeManager::themeChangedSignal,
            this, &MainWindow::themeChangedSlot);
}

void MainWindow::setUpStatusBar()
{
    QStatusBar *statusBar = this->statusBar();
    QLabel *statusLabel = new QLabel("Ready", this);
    statusBar->addPermanentWidget(statusLabel);
}

void MainWindow::setUpToolBar()
{
    QToolBar *toolbar         = addToolBar("Main Toolbar");
    QAction  *processorAction = new QAction("Processor", this);
    QAction  *runAction       = new QAction("Run", this);
    QAction  *pauseAction     = new QAction("Pause", this);
    QAction  *debugAction     = new QAction("Debug Run", this);
    QAction  *stepAction      = new QAction("Step", this);
    QAction  *undoAction      = new QAction("Undo", this);
    QAction  *redoAction      = new QAction("Redo", this);

    stepAction->setDisabled(true);
    pauseAction->setDisabled(true);
    undoAction->setDisabled(true);
    redoAction->setDisabled(true);

    // set toolbar icons (resources in :/icons)
    runAction->setIcon(IconManager::getInstance().getIcon(Icon::Play));
    pauseAction->setIcon(IconManager::getInstance().getIcon(Icon::Pause));
    undoAction->setIcon(IconManager::getInstance().getIcon(Icon::Undo));
    redoAction->setIcon(IconManager::getInstance().getIcon(Icon::Redo));
    stepAction->setIcon(IconManager::getInstance().getIcon(Icon::Step));
    // tooltips for accessibility
    processorAction->setToolTip("Processor settings");
    runAction->setToolTip("Run program");
    pauseAction->setToolTip("Pause execution");
    debugAction->setToolTip("Start debug run");
    stepAction->setToolTip("Execute single step");
    undoAction->setToolTip("Undo last VM step");
    redoAction->setToolTip("Redo last VM step");
    // optional: make icons a consistent size
    toolbar->setIconSize(QSize(18, 18));

    //------------Spinbox for setting execution speed----------------
    QSpinBox *spinbox = new QSpinBox(this);
    spinbox->setRange(1, 10000);
    spinbox->setValue(1000);
    spinbox->setSuffix(" ms");
    spinbox->setToolTip("Set Execution Speed (in milliseconds)");
    //---------------------------------------------------------------

    QWidgetAction *spinboxAction = new QWidgetAction(this);
    spinboxAction->setDefaultWidget(spinbox);
    toolbar->addAction(processorAction);
    toolbar->addAction(runAction);
    // toolbar->addAction(debugAction);
    toolbar->addAction(spinboxAction);
    toolbar->addAction(pauseAction);
    toolbar->addAction(stepAction);
    toolbar->addSeparator();
    toolbar->addAction(undoAction);
    toolbar->addAction(redoAction);

    connect(runAction, &QAction::triggered, this,
            [this, processorAction, runAction, pauseAction, debugAction]()
            {
                if (runAction->text() == "Run")
                {
                    debugAction->setDisabled(true);
                    processorAction->setDisabled(true);
                    pauseAction->setEnabled(true);
                    runAction->setText("Stop");
                    runAction->setIcon(IconManager::getInstance().getIcon(Icon::Stop));
                    runAction->setToolTip("Stop execution");
                    this->run();
                }
                else if (runAction->text() == "Stop")
                {
                    // emit stopSignal();
                    runAction->setText("Run");
                    runAction->setIcon(IconManager::getInstance().getIcon(Icon::Play));
                    runAction->setToolTip("Run program");
                    m_processorManager->stop();
                }
            });

    connect(debugAction, &QAction::triggered, this,
            [this, processorAction, runAction, pauseAction, stepAction, undoAction, redoAction,
             debugAction]()
            {
                debugAction->setDisabled(true);
                processorAction->setDisabled(true);
                pauseAction->setEnabled(true);
                stepAction->setEnabled(true);
                undoAction->setEnabled(true);
                redoAction->setEnabled(true);
                // setEditorNavigationEnabled(false);
                auto editorTab = dynamic_cast<EditorTab *>(m_tabs[TabIndex::EditorTabIndex]);
                if (editorTab)
                {
                    editorTab->setExpandedLocked(true);
                }
                m_processorManager->debugRun();
            });

    connect(processorAction, &QAction::triggered, this, &MainWindow::processorChangeDialog);

    connect(spinbox, qOverload<int>(&QSpinBox::valueChanged), this,
            [this](int value) { m_processorManager->setStepDelay(value); });

    connect(pauseAction, &QAction::triggered, this,
            [this, pauseAction, undoAction, redoAction]()
            {
                if (pauseAction->text() == "Pause")
                {
                    pauseAction->setText("Resume");
                    pauseAction->setIcon(IconManager::getInstance().getIcon(Icon::Resume));
                    pauseAction->setToolTip("Resume execution");
                    undoAction->setEnabled(true);
                    redoAction->setEnabled(true);
                    m_processorManager->pause();
                }
                else
                {
                    pauseAction->setText("Pause");
                    pauseAction->setIcon(IconManager::getInstance().getIcon(Icon::Pause));
                    pauseAction->setToolTip("Pause execution");
                    undoAction->setDisabled(true);
                    redoAction->setDisabled(true);
                    m_processorManager->resume();
                }
            });

    // we also connect the vm paused at breakpoint signal to change the pause button text
    connect(m_processorManager, &ProcessorManager::processorPausedAtBreakpointSignal, this,
            [this, pauseAction]()
            {
                pauseAction->setText("Resume");
                pauseAction->setIcon(IconManager::getInstance().getIcon(Icon::Resume));
                pauseAction->setToolTip("Resume execution");
            });

    connect(stepAction, &QAction::triggered, this, [this]() { m_processorManager->step(); });
    connect(undoAction, &QAction::triggered, this, [this]() { m_processorManager->undo(); });
    connect(redoAction, &QAction::triggered, this, [this]() { m_processorManager->redo(); });
}

void MainWindow::setUpSidebar()
{
    auto &iconManager = IconManager::getInstance();
    m_sidebar->addItem(new QListWidgetItem(iconManager.getIcon(Icon::Editor), "Editor"));
    m_sidebar->addItem(new QListWidgetItem(iconManager.getIcon(Icon::Memory), "Memory"));
    m_sidebar->addItem(new QListWidgetItem(iconManager.getIcon(Icon::Processor), "Processor"));
    m_sidebar->addItem(new QListWidgetItem(iconManager.getIcon(Icon::Cache), "Cache"));
    m_sidebar->addItem(new QListWidgetItem(iconManager.getIcon(Icon::Compiler), "Compiler"));
    m_sidebar->addItem(new QListWidgetItem(iconManager.getIcon(Icon::Profiler), "Profiler"));
    // Reuse the profiler icon until a dedicated optimizer icon is added.
    m_sidebar->addItem(new QListWidgetItem(iconManager.getIcon(Icon::Profiler), "Optimizer"));
    m_sidebar->setIconSize(QSize(20, 20));
    m_sidebar->setMinimumWidth(48);
    m_sidebar->setCurrentRow(0);
    // m_sidebar->setFocusPolicy(Qt::ClickFocus);

    connect(m_sidebar, &QListWidget::currentRowChanged, m_stackedTabs,
            &QStackedWidget::setCurrentIndex);
}

void MainWindow::setUpMenubar()
{
    QMenu *fileMenu     = menuBar()->addMenu("&File");
    QMenu *settingsMenu = menuBar()->addMenu("&Settings");
    QMenu *helpMenu     = menuBar()->addMenu("&Help");

    QMenu *preferencesMenu = new QMenu("Preferences", this);
    QMenu *processorMenu   = new QMenu("Processor", this);

    QAction *openAction  = new QAction(IconManager::getInstance().getIcon(Icon::Open), "Open", this);
    QAction *saveAction  = new QAction(IconManager::getInstance().getIcon(Icon::Save), "Save", this);
    QAction *exitAction  = new QAction("Exit", this);
    QAction *aboutAction = new QAction(IconManager::getInstance().getIcon(Icon::About), "About", this);

    ///////////File Menu///////////////////
    fileMenu->addAction(openAction);
    fileMenu->addAction(saveAction);
    fileMenu->addSeparator();
    fileMenu->addAction(exitAction);
    ////////////Setting Menu////////////////
    settingsMenu->addMenu(preferencesMenu);
    QActionGroup *themeGroup = new QActionGroup(this);
    themeGroup->setExclusive(true);
    for (const ThemeData &theme : ThemeManager::getInstance().availableThemes())
    {
        QAction *themeAction = new QAction(theme.name, this);
        themeAction->setCheckable(true);
        themeAction->setChecked(theme.id == ThemeManager::getInstance().currentThemeId());
        themeGroup->addAction(themeAction);
        preferencesMenu->addAction(themeAction);
        connect(themeAction, &QAction::triggered, this,
                [this, id = theme.id]() { toggleTheme(id); });
    }
    //----------------------------------------------
    settingsMenu->addMenu(processorMenu);
    QAction *wireStayActiveAction = new QAction("Wires Stay Active", this);
    wireStayActiveAction->setCheckable(true);
    wireStayActiveAction->setChecked(false);
    processorMenu->addAction(wireStayActiveAction);
    connect(wireStayActiveAction, &QAction::toggled, this,
            [this](bool checked)
            {
                auto processorTab =
                    dynamic_cast<ProcessorTab *>(m_tabs[TabIndex::ProcessorTabIndex]);
                if (processorTab)
                {
                    processorTab->setWiresStayActive(checked);
                }
            });
    //--------------------------------------------------
    QAction *advancedSettingsAction =
        new QAction(IconManager::getInstance().getIcon(Icon::Settings), "Advanced Settings", this);
    connect(advancedSettingsAction, &QAction::triggered, this,
            [this]()
            {
                SettingsDialog dialog(this);
                dialog.setWindowTitle("Advanced Processor Settings");
                dialog.exec();
            });
    settingsMenu->addAction(advancedSettingsAction);
    ///////////Help Menu///////////////////
    helpMenu->addAction(aboutAction);

    connect(openAction, &QAction::triggered, this,
            [this]()
            {
                QString filename = QFileDialog::getOpenFileName(
                    this, "Open File", "", "Assembly Files (*.asm *.s);;All Files (*)");

                if (!filename.isEmpty())
                {
                    QFile file(filename);
                    if (file.open(QIODevice::ReadOnly | QIODevice::Text))
                    {
                        QTextStream in(&file);
                        QString content = in.readAll();
                        auto editorTab =
                            dynamic_cast<EditorTab *>(m_tabs[TabIndex::EditorTabIndex]);
                        if (editorTab)
                        {
                            editorTab->setRawText(content);
                        }
                        file.close();
                    }
                }
            });

    connect(saveAction, &QAction::triggered, this,
            [this]()
            {
                QString filename = QFileDialog::getSaveFileName(
                    this, "Save File", "", "Assembly Files (*.asm *.s);;All Files (*)");

                if (!filename.isEmpty())
                {
                    QFile file(filename);
                    if (file.open(QIODevice::WriteOnly | QIODevice::Text))
                    {
                        QTextStream out(&file);
                        auto editorTab =
                            dynamic_cast<EditorTab *>(m_tabs[TabIndex::EditorTabIndex]);
                        if (editorTab)
                        {
                            out << editorTab->getRawText().c_str();
                        }
                        file.close();
                    }
                }
            });
}


void MainWindow::setUpTabs()
{
    m_tabs[TabIndex::EditorTabIndex] = new EditorTab(this);

    m_tabs[TabIndex::MemoryTabIndex] =
        new MemoryTab(this, m_processorManager->getMemoryController());

    m_tabs[TabIndex::ProcessorTabIndex] =
        new ProcessorTab(this, m_processorManager);

    m_tabs[TabIndex::CacheTabIndex] =
        new CacheTab(this, m_processorManager->getMemoryController());

    m_tabs[TabIndex::CompilerTabIndex] = new CompilerTab(this);

    m_tabs[TabIndex::ProfilerTabIndex] =
        new ProfilerTab(this, m_processorManager->getProfiler());

    m_tabs[TabIndex::OptimizerTabIndex] = new OptimizerTab(
        dynamic_cast<EditorTab *>(m_tabs[TabIndex::EditorTabIndex]),
        this
    );

    // Connect optimized execution to the existing processor.
    auto *optimizerTab =
        dynamic_cast<OptimizerTab *>(m_tabs[TabIndex::OptimizerTabIndex]);

    optimizerTab->setLoadHandler(
        [this](const AssembledProgram &optimizedProgram)
        {
            m_processorManager->reset();
            m_processorManager->loadProgram(optimizedProgram);
            emit runProcessorSignal();
        });

    connect(this, &MainWindow::processorChangedSignal,
            dynamic_cast<ProcessorTab *>(m_tabs[TabIndex::ProcessorTabIndex]),
            &ProcessorTab::onVMChanged);

    optimizerTab->setBenchmarkHandler(
        [this](const AssembledProgram &originalProgram,
               const AssembledProgram &optimizedProgram,
               bool withForwarding)
        {
            // Use the same hazard model that was selected when suggestions
            // were generated for BOTH benchmark runs.
            processorChanged(withForwarding
                ? ProcessorType::RV5Stage_H_F
                : ProcessorType::RV5Stage_H_NF);

            m_benchmarkOriginalProgram = originalProgram;
            m_benchmarkOptimizedProgram = optimizedProgram;

            startBenchmarkOriginalRun();
        });

    m_stackedTabs->addWidget(m_tabs[TabIndex::EditorTabIndex]);
    m_stackedTabs->addWidget(m_tabs[TabIndex::MemoryTabIndex]);
    m_stackedTabs->addWidget(m_tabs[TabIndex::ProcessorTabIndex]);
    m_stackedTabs->addWidget(m_tabs[TabIndex::CacheTabIndex]);
    m_stackedTabs->addWidget(m_tabs[TabIndex::CompilerTabIndex]);
    m_stackedTabs->addWidget(m_tabs[TabIndex::ProfilerTabIndex]);
    m_stackedTabs->addWidget(m_tabs[TabIndex::OptimizerTabIndex]);


}


bool MainWindow::tryParseAndLoadProgram()
{
    auto* editor = dynamic_cast<EditorTab*>(m_tabs[TabIndex::EditorTabIndex]);
    auto* profilerTab = dynamic_cast<ProfilerTab*>(m_tabs[TabIndex::ProfilerTabIndex]);

    if(!editor || !profilerTab)
    {
        QMessageBox::critical(this, "Error", "Editor or Profiler tab not found.");
        return false;
    }
    editor->switchToExpandedView(); // switch to the expanded view
                                    //to show expanded pseudoinstructions
    editor->resetErrorLines();    // we reset previous error lines
    editor->setCanWrite(false);   // we disable writing in editor while vm is running
    m_processorManager->reset();
    try
    {
        std::string rawText = editor->getRawText();
        rawText = customPseudoManager::expandPseudoInstruction(rawText);
        std::ofstream out(globals::temporary_assembly_file_path);
        out << rawText;
        out.close();
        AssembledProgram assembledProgram = assemble(globals::temporary_assembly_file_path.string());
        DumpDisasssembly(globals::disassembly_file_path, assembledProgram);
        std::ifstream in(globals::disassembly_file_path);
        std::stringstream buffer;
        buffer << in.rdbuf();
        editor->updateDisassemblyView(buffer.str());
        profilerTab->setSourceText(QString::fromStdString(rawText));

        m_processorManager->loadProgram(assembledProgram);
        m_processorManager->setBreakpoints(editor->getBreakpoints());
        return true;
    }
    catch (const std::exception &e)
    {
        editor->setErrorLinesFromFile(globals::errors_dump_file_path);
        QMessageBox::critical(this, "Error", e.what());
        return false;
    }
}

void MainWindow::run()
{
    // as soon s as run is clicked we disable the toolbar buttons
    // disableToolBarButtons();
    if (tryParseAndLoadProgram())
    {

        auto editorTab = dynamic_cast<EditorTab *>(m_tabs[TabIndex::EditorTabIndex]);
        if (editorTab)
        {
            editorTab->setExpandedLocked(true);
        }

        emit runProcessorSignal();
    }
    else
    {
        // if parsing or loading failed we re-enable the buttons
        // otherwise if the vm starts running the buttons will be re-enabled when vm finishes
        runFinishedSlot();
    }
}

void MainWindow::processorChangeDialog()
{
    ProcessorDialog dialog(this, m_processorManager->getProcessorType());
    dialog.setWindowTitle("Choose Processor");
    connect(&dialog, &ProcessorDialog::vmSelected, this, &MainWindow::processorChanged);
    dialog.exec();
}

void MainWindow::processorChanged(const ProcessorType &vmType)
{
    m_processorManager->changeProcessor(vmType);
    m_registerContainer->setRegisterFile(m_processorManager->getRegisterFile());
    auto *memtab = dynamic_cast<MemoryTab *>(m_tabs[TabIndex::MemoryTabIndex]);
    if (memtab)
    {
        memtab->changeMemoryController(m_processorManager->getMemoryController());
    }
    auto *cacheTab = dynamic_cast<CacheTab *>(m_tabs[TabIndex::CacheTabIndex]);
    if (cacheTab)
    {
        cacheTab->changeMemoryController(m_processorManager->getMemoryController());
    }
    emit processorChangedSignal();

    // well also have to change the processor design from here later
}


void MainWindow::startBenchmarkOriginalRun()
{
    if (!m_benchmarkOptimizedProgram)
    {
        qDebug() << "[Benchmark] Optimized program is missing.";

        m_benchmarkStage = BenchmarkStage::Idle;
        m_benchmarkOriginalProgram.reset();
        m_benchmarkOptimizedProgram.reset();

        QMessageBox::warning(
            this, "Benchmark",
            "Optimized program is missing.");

        auto *editor =
            dynamic_cast<EditorTab *>(m_tabs[TabIndex::EditorTabIndex]);

        if (editor) {
            editor->setCanWrite(true);
        }

        return;
    }
    m_originalMetrics = PerformanceMetrics{};
    m_optimizedMetrics = PerformanceMetrics{};
    m_benchmarkStage = BenchmarkStage::OriginalRun;

    auto *editor =
        dynamic_cast<EditorTab *>(m_tabs[TabIndex::EditorTabIndex]);

    if (editor) {
        editor->setCanWrite(false);
        editor->setExpandedLocked(true);
    }

    qDebug() << "[Benchmark] Processor type:"
         << static_cast<int>(m_processorManager->getProcessorType());

    m_processorManager->clearBreakpoints();
    m_processorManager->reset();
    m_processorManager->loadProgram(*m_benchmarkOriginalProgram);

    emit runProcessorSignal();
}

void MainWindow::startBenchmarkOptimizedRun()
{
    if (!m_benchmarkOptimizedProgram)
    {
        qDebug() << "[Benchmark] Optimized program is missing.";

        m_benchmarkStage = BenchmarkStage::Idle;
        QMessageBox::warning(
            this, "Benchmark",
            "Optimized program is missing.");
        return;
    }

    qDebug() << "[Benchmark] Loading optimized program.";
    qDebug() << "[Benchmark] Intermediate code size:"
             << m_benchmarkOptimizedProgram->intermediate_code.size();
    qDebug() << "[Benchmark] Text buffer size:"
             << m_benchmarkOptimizedProgram->text_buffer.size();

    m_processorManager->clearBreakpoints();
    m_processorManager->reset();
    m_processorManager->loadProgram(*m_benchmarkOptimizedProgram);

    qDebug() << "[Benchmark] Optimized program loaded; starting processor.";

    emit runProcessorSignal();
}

// KITES Phase 1 contribution: capture each run and sequence original then optimized execution.
void MainWindow::runFinishedSlot()
{
    static std::array<uint64_t, 32> originalGprs{};

    qDebug() << "[Benchmark] runFinishedSlot entered; stage ="
         << static_cast<int>(m_benchmarkStage);

    if (m_benchmarkStage == BenchmarkStage::OriginalRun)
    {
        captureBenchmarkMetrics(m_originalMetrics);
        {
            auto* registers = m_processorManager->getRegisterFile();
            for (std::size_t i = 0; i < originalGprs.size(); ++i) {
                originalGprs[i] = registers->ReadGpr(
                    static_cast<uint8_t>(i));
            }
            qDebug() << "[VERIFY] Saved original register values.";
        }

        m_benchmarkStage = BenchmarkStage::OptimizedRun;
        qDebug() << "[Benchmark] Original finished; starting optimized run";
        startBenchmarkOptimizedRun();
        return;
    }

    if (m_benchmarkStage == BenchmarkStage::OptimizedRun)
    {
        captureBenchmarkMetrics(m_optimizedMetrics);
        {
            auto* registers = m_processorManager->getRegisterFile();
            bool registersMatch = true;

            for (std::size_t i = 0; i < originalGprs.size(); ++i) {
                const uint64_t optimizedValue = registers->ReadGpr(
                    static_cast<uint8_t>(i));

                if (originalGprs[i] != optimizedValue) {
                    registersMatch = false;
                    qDebug() << "[VERIFY] MISMATCH:"
                             << "x" << i
                             << "original =" << originalGprs[i]
                             << "optimized =" << optimizedValue;
                }
            }

            qDebug() << "[VERIFY] Register comparison:"
                     << (registersMatch ? "PASS" : "FAIL");
        }

        auto *optimizerTab =
            dynamic_cast<OptimizerTab *>(
                m_tabs[TabIndex::OptimizerTabIndex]);

        if (optimizerTab) {
            OptimizerBenchmarkMetrics original{
                m_originalMetrics.cycles,
                m_originalMetrics.stalls,
                m_originalMetrics.instructionsRetired,
                m_originalMetrics.cpi
            };

            OptimizerBenchmarkMetrics optimized{
                m_optimizedMetrics.cycles,
                m_optimizedMetrics.stalls,
                m_optimizedMetrics.instructionsRetired,
                m_optimizedMetrics.cpi
            };

            qDebug() << "[Benchmark] Both runs finished; showing results";

            optimizerTab->showBenchmarkResults(original, optimized);
        }

        m_benchmarkStage = BenchmarkStage::Idle;
        m_benchmarkOriginalProgram.reset();
        m_benchmarkOptimizedProgram.reset();
    }

    auto *editor =
    dynamic_cast<EditorTab *>(m_tabs[TabIndex::EditorTabIndex]);

    if (editor) {
        editor->setCanWrite(true);
    } // re-enable writing in editor when vm stops
    editor->setExpandedLocked(false);
    editor->clearHighlights(); // we clear any highlights when processor stops
    // other we are not alble to move the cursor as the paint
    //  keeps jumping to last highlighted line
    editor->switchToEditorView();
    QList<QToolBar *> toolbars = this->findChildren<QToolBar *>();
    // since we only have one toolbar we can directly access it
    for (QAction *action : toolbars[0]->actions())
    {
        if (action->text() == "Run" || action->text() == "Processor" ||
            action->text() == "Debug Run")
        {
            action->setEnabled(true);
        }
        if (action->text() == "Stop")
        {
            action->setText("Run");
            action->setIcon(IconManager::getInstance().getIcon(Icon::Play));
            action->setToolTip("Run program");
            // when the program finishes we set the run button text back to run
        }
        if (action->text() == "Resume")
        {
            action->setText("Pause");
            action->setIcon(IconManager::getInstance().getIcon(Icon::Pause));
            action->setToolTip("Pause execution");
            // in case we stop while paused
        }

        if (action->text() == "Pause" || action->text() == "Stop")
        {
            action->setDisabled(true);
        }
    }

}


void MainWindow::toggleTheme(const QString &themeId)
{
    ThemeManager::getInstance().setTheme(themeId);
}

void MainWindow::themeChangedSlot([[maybe_unused]] const QString &themeId)
{
    // we will update the icons here based on the theme
    // this is very very hacky but this will do for now
    auto *toolbar = this->findChild<QToolBar *>();
    if (toolbar)
    {
        for (QAction *action : toolbar->actions())
        {
            if (action->text() == "Run")
            {
                action->setIcon(IconManager::getInstance().getIcon(Icon::Play));
            }
            else if (action->text() == "Pause")
            {
                action->setIcon(IconManager::getInstance().getIcon(Icon::Pause));
            }
            else if (action->text() == "Resume")
            {
                action->setIcon(IconManager::getInstance().getIcon(Icon::Resume));
            }
            else if (action->text() == "Stop")
            {
                action->setIcon(IconManager::getInstance().getIcon(Icon::Stop));
            }
            else if (action->text() == "Undo")
            {
                action->setIcon(IconManager::getInstance().getIcon(Icon::Undo));
            }
            else if (action->text() == "Redo")
            {
                action->setIcon(IconManager::getInstance().getIcon(Icon::Redo));
            }
            else if (action->text() == "Step")
            {
                action->setIcon(IconManager::getInstance().getIcon(Icon::Step));
            }
        }
    }

    // sidebar icons
    static const std::array<Icon, toIndex(TabIndex::TabCount)> sidebarIcons = {
        Icon::Editor, Icon::Memory, Icon::Processor, Icon::Cache, Icon::Compiler, Icon::Profiler, Icon::Profiler};
    for (int row = 0; row < m_sidebar->count(); ++row)
    {
        if (row < static_cast<int>(sidebarIcons.size()))
            m_sidebar->item(row)->setIcon(IconManager::getInstance().getIcon(sidebarIcons[row]));
    }

    // menu bar action icons
    for (QAction *action : this->findChildren<QAction *>())
    {
        if (action->text() == "Open")
            action->setIcon(IconManager::getInstance().getIcon(Icon::Open));
        else if (action->text() == "Save")
            action->setIcon(IconManager::getInstance().getIcon(Icon::Save));
        else if (action->text() == "About")
            action->setIcon(IconManager::getInstance().getIcon(Icon::About));
        else if (action->text() == "Advanced Settings")
            action->setIcon(IconManager::getInstance().getIcon(Icon::Settings));
    }
}

MainWindow::~MainWindow()
{
    m_processorManager->stop();
    if(m_processorThread->isRunning())
    {
        m_processorThread->quit();
        m_processorThread->wait();
    }
    // delete ui;
}


void MainWindow::captureBenchmarkMetrics(PerformanceMetrics &metrics)
{
    metrics.cycles = m_processorManager->getCycles();
    metrics.instructionsRetired =
        m_processorManager->getInstructionsRetired();

    // Calculate CPI from the metrics captured for this run.
    // CPI = cycles / instructions retired.
    metrics.cpi = metrics.instructionsRetired > 0
        ? static_cast<float>(metrics.cycles) /
              static_cast<float>(metrics.instructionsRetired)
        : 0.0f;

    // Keep the existing API for now; its value is not yet verified
    // to represent cumulative stall cycles.
    metrics.stalls = m_processorManager->getTotalStallCycles();
}


} // namespace Kites
