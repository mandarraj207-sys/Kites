#pragma once
#include "../circuit_scene.h"
namespace Kites
{
class RV5StageVM_H_NF_CircuitScene : public CircuitScene
{
    Q_OBJECT
  public:
    explicit RV5StageVM_H_NF_CircuitScene(QObject *parent = nullptr) : CircuitScene(parent)
    {
        loadScene(":/circuit_designs/H_NF_Processor.json");
    }
};
} // namespace Kites
